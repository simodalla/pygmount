:mod:`apt.progress.text` --- Progress reporting for text interfaces
===================================================================
.. automodule:: apt.progress.text


Acquire Progress Reporting
--------------------------
.. autoclass:: AcquireProgress
    :members:


CD-ROM Progress Reporting
--------------------------
.. autoclass:: CdromProgress
    :members:

Operation Progress Reporting
-----------------------------
.. autoclass:: OpProgress
    :members:

